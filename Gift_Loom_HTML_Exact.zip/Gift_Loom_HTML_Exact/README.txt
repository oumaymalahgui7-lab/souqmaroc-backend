Gift Loom – reconstructed HTML version
========================================
This project was reconstructed from the supplied Gift Loom APK assets/resources and application strings.

Identified Android screens/classes include:
- SplashactivityActivity
- LoginActivity / Login2Activity
- RegisteractivityActivity
- MainActivity
- DailyActivity
- RewardsActivity
- SpinActivity
- ScrachActivity
- InviteActivity / Invit2Activity
- ProfilActivity
- SittingActivity (Settings)
- SupportActivity
- DrawsActivity
- UpdateActivity
- ActivityBannedActivity
- notification-related UI
- reward/redeem flows

The HTML version provides a screen-by-screen single-page reconstruction with:
- real Gift Loom artwork extracted from the APK
- login/register flow
- points and streak UI
- daily tasks
- rewards and redemption screens
- spin wheel using the APK wheel artwork
- scratch-card flow
- invite code flow
- profile/settings/support/notifications
- terms/privacy/about dialogs
- localStorage state

Important:
This is a functional web reconstruction, not a literal conversion of Android bytecode.
The original APK uses Android Native components and Firebase. A web app cannot directly execute those Android classes.
Firebase authentication/database and server-side reward verification would need to be connected separately for production use.
